package hw1;

public enum Category {
	Food,
	Beverage,
	Home,
	Snack,
	Personal,	
}
