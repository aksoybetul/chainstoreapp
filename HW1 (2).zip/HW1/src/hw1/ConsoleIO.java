package hw1;

import java.util.Scanner;

public class ConsoleIO {

	Scanner keyboard;
	
	public ConsoleIO() {
		keyboard = new Scanner(System.in);
	}

	public int getIntInput() {
		int integer = keyboard.nextInt();
		return integer;
	}

	public String getStringInput() {
		String input = keyboard.next();
		return input;
	}

	public String getNextLine() {
		return keyboard.nextLine();
	}
	

	public void displayMenu() {
		System.out.println("****************************************************************************************************************");
		System.out.println("Choose an option to execute: ");
		System.out.println("Enter [1] : Most profitable item for the whole year");
		System.out.println("Enter [2] : Most profitable category for the whole year");
		System.out.println("Enter [3] : - Least profitable item for the whole year");
		System.out.println("Enter [4] : Least profitable category for the whole year ");
		System.out.println("Enter [5] : Most profitable item for a single sale ");
		System.out.println("Enter [6] : Best-selling item for the whole year ");
		System.out.println("Enter [7] : Most profitable store for each month\r\n");
		System.out.println("Enter [8] : Quit.");
		System.out.println("****************************************************************************************************************");
	}
	
}
