package hw1;


public class AnnualSale {

	ItemTransaction[] itemtransaction = new ItemTransaction[32];
	
	
	
	
}
