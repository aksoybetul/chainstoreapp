package hw1;

public class StoreQuery {

	FileIO file;
	ConsoleIO console;
	Transaction transaction;
	Transaction[][] transactions;
	Item item;
	Item[] items;

	// Option 1
	public void mostProfitableItemForTheWholeYear() {
		int maxProfit = 0;
		String itemName= "";
		for (int i = 0; i < 32; i++) {
			int profit = 0;
			for (int j = 0; j < 12; j++) {
				profit += transactions[i][j].getProfit();
				
			}
			
			if(profit >maxProfit) {
				maxProfit = profit;
				
			}
		
		}

		System.out.println("Most profitable item for the whole year is ");
	}

	// Option 2
	public void mostProfitableCategoryForTheWholeYear() {
		String categoryName = item.getCategory().toString();
		for (int i = 0; i < transactions.length; i++) {

		}

		System.out.println("Most profitable category for the whole year is " + categoryName);
	}

	// Option 3
	public void leastProfitableItemForTheWholeYear() {
		String itemName = item.getName();
		for (int i = 0; i < transactions.length; i++) {

		}

		System.out.println("Least profitable item for the whole year is " + itemName);
	}

	// Option 4
	public void leastProfitableCategoryForTheWholeYear() {
		String categoryName = item.getCategory().toString();
		for (int i = 0; i < transactions.length; i++) {

		}

		System.out.println("Least profitable category for the whole year is " + categoryName);
	}

	// Option 5
	public void mostProfitableItemForaSingleSale() {

	}

	// Option 6
	public void bestSellingItemForTheWholeYear() {

	}

	// Option 7
	public void mostProfitableForEachMonth() {

	}

}
