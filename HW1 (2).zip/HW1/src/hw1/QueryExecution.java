package hw1;

import java.text.ParseException;

public class QueryExecution {


		StoreQuery query;
		ConsoleIO console;
		FileIO file;
		
		public QueryExecution() {
			this.query = new StoreQuery();
			this.console = new ConsoleIO();
			this.file = new FileIO();
		}

		public boolean options() throws ParseException {
			int option = console.getIntInput();
			console.getNextLine();

			switch (option) {
			case 1: flat.listOfFlats();
				return true;
			case 2: bill.listOfBills();
				return true;
			case 3: doc.changeFileName();
				return true;
			case 4:
				query.amountOfUnpaidBills();
				return true;
			case 5:
				query.amountOfUnpaidCertainBillType();
				return true;
			case 6:
				query.amountOfCertainFloor();
				return true;
			case 7:
				query.listOfUnpaidBillsInfo();
				return true;
			case 8:
				query.totalAmountAndNumOfPaidBillsCertainDate();
				return true;
			case 9:
				query.totalAmountAndNumOfUnpaidBillsCertainTypeThatPassedDeadline();
				return true;
			case 10:
				query.averageAmountOfNRoomFlats();
				return true;
			case 11:
				query.averageAmounfOfNSqrMeter();
				return true;
			case 12:
				System.out.println("You're out of the system.");
				return false;
			default:
				System.err.println();
				System.err.println("Please try again!");
				System.err.println();
				return true;
			}

		}

}
