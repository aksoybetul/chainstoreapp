package hw1;

import java.io.IOException;
import java.text.ParseException;

public class ChainStoreApp {

	public static void main(String[] args) throws IOException, ParseException {

		AnnualSale annualSale = new AnnualSale();

		FileIO f = new FileIO();
		Item[] items = f.readItems("HW1_items.csv");
		String f1 = "HW1_Transactions_Store1.csv";
		String f2 = "HW1_Transactions_Store2.csv";
		String f3 = "HW1_Transactions_Store3.csv";
		String f4 = "HW1_Transactions_Store4.csv";

		Transaction[][] transactions1 = f.readTransactions(f1);

		
		for (int i = 0; i < items.length; i++) {
			annualSale.itemtransaction[items[i].getId() - 1] = new ItemTransaction(items[i]);
		}
		
		ItemTransaction itemTransaction[][] ;
		for(int i=0; i<4 ; i++) {
			for(int j = 0; j < 12; j++) {
				if (annualSale.itemtransaction[i].getItem().getId() == 1 ) {
					itemTransaction[1][j] = (itemTrasnaction) new ItemTransaction(items[i]).getTransactions();
					
				}
				
			}
		}

	}
}

/*
 * ChainStoreManager manager = new ChainStoreManager(); manager.start();
 */
