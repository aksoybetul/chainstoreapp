package hw1;

import java.text.ParseException;

public class ChainStoreManager {

	private ConsoleIO console;
	private FileIO file;
	
	
	public void start() throws ParseException {
		  
		  ConsoleIO console = new ConsoleIO();
		  QueryExecution exec = new QueryExecution();
		  
		  while(true) {
		   console.displayMenu();
		   if(!exec.options()) {
		    break;
		   }
		  }
	}
}
