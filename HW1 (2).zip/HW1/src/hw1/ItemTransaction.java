package hw1;


public class ItemTransaction {
	private Item item;
	private Transaction[][] transactions;
	private double profit;
	
	public ItemTransaction(Item item) {
		this.item=item;
		this.transactions= new Transaction [4][12];
				
	}
	
			
	
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public Transaction[][] getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction[][] transactions) {
		this.transactions = transactions;
	}
}
